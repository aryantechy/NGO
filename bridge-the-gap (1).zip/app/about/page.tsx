import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight, Users, Award, Target, Clock, Calendar, MapPin, Mail, Phone, CheckCircle } from "lucide-react"
import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
              B
            </div>
            <span className="font-bold text-xl">Bridge the Gap</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/opportunities" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Find Opportunities
            </Link>
            <Link href="/donate" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Donate Food
            </Link>
            <Link href="/volunteer" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Volunteer Skills
            </Link>
            <Link href="/about" className="text-sm font-medium text-purple-600 border-b-2 border-purple-600 pb-1">
              About Us
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="outline" size="sm">
                Log In
              </Button>
            </Link>
            <Link href="/signup">
              <Button
                className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white"
                size="sm"
              >
                Sign Up
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-pink-50 -z-10" />
          <div className="absolute -right-40 -top-40 w-96 h-96 bg-gradient-to-br from-purple-200/30 to-pink-200/30 rounded-full blur-3xl -z-10" />
          <div className="absolute -left-40 -bottom-40 w-96 h-96 bg-gradient-to-br from-purple-200/30 to-pink-200/30 rounded-full blur-3xl -z-10" />

          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-block px-3 py-1 rounded-full bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 text-sm font-medium mb-4">
                  Our Mission
                </div>
                <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
                  Bridging the Gap Between{" "}
                  <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-500">
                    Surplus and Scarcity
                  </span>
                </h1>
                <p className="text-lg text-gray-600 mb-8">
                  We're on a mission to create a more efficient food distribution system by connecting skilled
                  volunteers, food donors, and recipients through technology and community engagement.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button
                    className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white"
                    size="lg"
                  >
                    Join Our Mission
                  </Button>
                  <Button variant="outline" size="lg">
                    Learn More
                  </Button>
                </div>
              </div>
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-400/10 to-pink-400/10 rounded-3xl -z-10 transform rotate-3" />
                <div className="relative bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
                  <Image
                    src="/placeholder.svg?height=600&width=800"
                    alt="Team working together"
                    width={800}
                    height={600}
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Our Story */}
        <section className="py-20 bg-white">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">Our Story</h2>
              <p className="text-gray-600">
                Bridge the Gap was founded with a simple idea: connect those with professional skills to food assistance
                organizations to create more efficient systems.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="relative rounded-xl overflow-hidden h-96">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="Founders of Bridge the Gap"
                  width={800}
                  height={600}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-6">From Idea to Impact</h3>
                <div className="space-y-6">
                  <p className="text-gray-700">
                    Bridge the Gap was founded in 2020 by a group of tech professionals who witnessed the inefficiencies
                    in food distribution systems during the COVID-19 pandemic. They saw food banks struggling with
                    inventory management while restaurants and grocery stores were discarding surplus food.
                  </p>
                  <p className="text-gray-700">
                    What began as a simple app to track food inventory has grown into a comprehensive platform that
                    connects skilled volunteers, food donors, and recipients. Our founders recognized that by applying
                    professional expertise to food assistance organizations, we could create more efficient systems that
                    help more people.
                  </p>
                  <p className="text-gray-700">
                    Today, Bridge the Gap operates in 15 cities across the country, has facilitated the distribution of
                    over 250,000 meals, and has engaged more than 10,000 skilled volunteers who contribute their
                    professional expertise to fight food insecurity.
                  </p>
                </div>
                <div className="mt-8">
                  <Link href="#" className="inline-flex items-center text-purple-600 hover:text-purple-800 font-medium">
                    Read our full story <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Our Values */}
        <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">Our Values</h2>
              <p className="text-gray-600">These core principles guide everything we do at Bridge the Gap.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  title: "Community First",
                  description:
                    "We believe in the power of community to solve complex problems. By bringing together diverse skills and resources, we create sustainable solutions to food insecurity.",
                  icon: Users,
                  color: "from-purple-500 to-purple-700",
                },
                {
                  title: "Skill-Based Impact",
                  description:
                    "Professional skills can multiply the impact of traditional volunteering. We harness expertise to create efficient systems that serve more people with the same resources.",
                  icon: Award,
                  color: "from-pink-500 to-pink-700",
                },
                {
                  title: "Sustainable Solutions",
                  description:
                    "We focus on creating lasting change through systems improvement, not just temporary relief. Our goal is to build infrastructure that continues to serve communities for years to come.",
                  icon: Target,
                  color: "from-purple-500 to-pink-500",
                },
              ].map((value, i) => (
                <div key={i} className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-100 to-pink-100 rounded-xl transform transition-transform group-hover:scale-[1.02] duration-300" />
                  <div className="relative p-8 bg-white rounded-xl border border-gray-100 shadow-sm h-full transition-transform group-hover:translate-y-[-4px] duration-300">
                    <div
                      className={`w-12 h-12 rounded-lg bg-gradient-to-br ${value.color} flex items-center justify-center text-white mb-6`}
                    >
                      <value.icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold mb-3">{value.title}</h3>
                    <p className="text-gray-600">{value.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Our Impact */}
        <section className="py-20 bg-white">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">Our Impact</h2>
              <p className="text-gray-600">
                Since our founding, we've made a significant difference in communities across the country.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
              {[
                { value: "10K+", label: "Volunteers" },
                { value: "500+", label: "Partner Organizations" },
                { value: "250K", label: "Meals Distributed" },
                { value: "85%", label: "Reduction in Food Waste" },
              ].map((stat, i) => (
                <div key={i} className="text-center">
                  <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-purple-100 to-pink-100 mb-4">
                    <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-500">
                      {stat.value}
                    </span>
                  </div>
                  <p className="font-medium text-gray-800">{stat.label}</p>
                </div>
              ))}
            </div>

            <Tabs defaultValue="stories" className="max-w-4xl mx-auto">
              <TabsList className="grid w-full grid-cols-3 mb-8">
                <TabsTrigger
                  value="stories"
                  className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                >
                  Success Stories
                </TabsTrigger>
                <TabsTrigger
                  value="partners"
                  className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                >
                  Partner Organizations
                </TabsTrigger>
                <TabsTrigger
                  value="reports"
                  className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                >
                  Impact Reports
                </TabsTrigger>
              </TabsList>

              <TabsContent value="stories" className="space-y-8">
                <div className="grid md:grid-cols-2 gap-8">
                  {[
                    {
                      title: "Community Food Bank Transformation",
                      location: "San Francisco, CA",
                      description:
                        "A team of database experts and logistics professionals helped the Community Food Bank implement a new inventory management system, reducing waste by 40% and increasing distribution capacity by 35%.",
                      image: "/placeholder.svg?height=300&width=500",
                    },
                    {
                      title: "Mobile App for Food Rescue",
                      location: "Chicago, IL",
                      description:
                        "Volunteer developers created a mobile app that connects restaurants with surplus food to nearby shelters, resulting in 15,000 meals rescued in the first six months.",
                      image: "/placeholder.svg?height=300&width=500",
                    },
                  ].map((story, i) => (
                    <div key={i} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                      <div className="h-48 relative">
                        <Image
                          src={story.image || "/placeholder.svg"}
                          alt={story.title}
                          width={500}
                          height={300}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="p-6">
                        <h3 className="text-xl font-bold mb-2">{story.title}</h3>
                        <p className="text-sm text-gray-500 mb-4 flex items-center">
                          <MapPin className="h-4 w-4 mr-1" /> {story.location}
                        </p>
                        <p className="text-gray-700 mb-4">{story.description}</p>
                        <Button variant="outline" className="w-full">
                          Read Full Story
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="text-center">
                  <Button variant="outline">View All Success Stories</Button>
                </div>
              </TabsContent>

              <TabsContent value="partners" className="space-y-8">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                    <div
                      key={i}
                      className="bg-white rounded-xl p-6 border border-gray-100 flex items-center justify-center hover:shadow-md transition-shadow"
                    >
                      <Image
                        src="/placeholder-logo.svg"
                        width={120}
                        height={60}
                        alt={`Partner organization ${i}`}
                        className="opacity-80 hover:opacity-100 transition-opacity"
                      />
                    </div>
                  ))}
                </div>
                <div className="text-center">
                  <Button variant="outline">Become a Partner</Button>
                </div>
              </TabsContent>

              <TabsContent value="reports" className="space-y-8">
                <div className="space-y-4">
                  {[
                    {
                      title: "Annual Impact Report 2023",
                      description:
                        "A comprehensive overview of our impact across all programs and initiatives in 2023.",
                      date: "January 2024",
                      icon: Calendar,
                    },
                    {
                      title: "Food Waste Reduction Study",
                      description:
                        "Research on how our programs have contributed to reducing food waste in partner communities.",
                      date: "October 2023",
                      icon: Clock,
                    },
                    {
                      title: "Volunteer Skills Impact Analysis",
                      description:
                        "An analysis of how skilled volunteering multiplies the impact of traditional volunteering efforts.",
                      date: "July 2023",
                      icon: Users,
                    },
                  ].map((report, i) => (
                    <div
                      key={i}
                      className="bg-white rounded-xl p-6 border border-gray-100 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-start">
                        <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center mr-4 flex-shrink-0">
                          <report.icon className="h-6 w-6 text-purple-600" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-bold mb-1">{report.title}</h3>
                          <p className="text-sm text-gray-500 mb-2">{report.date}</p>
                          <p className="text-gray-700 mb-4">{report.description}</p>
                          <Button variant="outline" size="sm">
                            Download Report
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="text-center">
                  <Button variant="outline">View All Reports</Button>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">Meet Our Team</h2>
              <p className="text-gray-600">
                The passionate individuals behind Bridge the Gap who are dedicated to creating a more efficient food
                distribution system.
              </p>
            </div>

            <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-8 max-w-5xl mx-auto">
              {[
                {
                  name: "Sarah Chen",
                  title: "Co-Founder & CEO",
                  image: "/placeholder.svg?height=300&width=300",
                  bio: "Former tech executive with a passion for social impact",
                },
                {
                  name: "Michael Rodriguez",
                  title: "Co-Founder & CTO",
                  image: "/placeholder.svg?height=300&width=300",
                  bio: "Software engineer focused on creating technology for good",
                },
                {
                  name: "Jessica Kim",
                  title: "Director of Operations",
                  image: "/placeholder.svg?height=300&width=300",
                  bio: "Logistics expert with experience in food distribution networks",
                },
                {
                  name: "David Thompson",
                  title: "Partnerships Director",
                  image: "/placeholder.svg?height=300&width=300",
                  bio: "Former nonprofit executive specializing in community partnerships",
                },
                {
                  name: "Aisha Patel",
                  title: "Volunteer Coordinator",
                  image: "/placeholder.svg?height=300&width=300",
                  bio: "HR professional passionate about connecting talent with causes",
                },
                {
                  name: "James Wilson",
                  title: "Technology Lead",
                  image: "/placeholder.svg?height=300&width=300",
                  bio: "Full-stack developer focused on creating intuitive user experiences",
                },
                {
                  name: "Maria Gonzalez",
                  title: "Community Outreach",
                  image: "/placeholder.svg?height=300&width=300",
                  bio: "Community organizer with deep connections in food security initiatives",
                },
                {
                  name: "Robert Lee",
                  title: "Data & Analytics",
                  image: "/placeholder.svg?height=300&width=300",
                  bio: "Data scientist helping measure and maximize our impact",
                },
              ].map((member, i) => (
                <div
                  key={i}
                  className="bg-white rounded-xl shadow-sm overflow-hidden group hover:shadow-md transition-shadow duration-300"
                >
                  <div className="aspect-square relative overflow-hidden">
                    <Image
                      src={member.image || "/placeholder.svg"}
                      alt={member.name}
                      width={300}
                      height={300}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-4 text-center">
                    <h3 className="font-bold text-lg">{member.name}</h3>
                    <p className="text-purple-600 text-sm mb-2">{member.title}</p>
                    <p className="text-gray-600 text-sm">{member.bio}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center mt-12">
              <Button variant="outline">View Full Team</Button>
            </div>
          </div>
        </section>

        {/* Join Us Section */}
        <section className="py-20 bg-white">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center max-w-5xl mx-auto">
              <div>
                <h2 className="text-3xl font-bold mb-6">Join Our Team</h2>
                <p className="text-gray-700 mb-6">
                  We're always looking for passionate individuals to join our team. Whether you're interested in a
                  full-time role or want to contribute as a volunteer, there are many ways to get involved.
                </p>

                <div className="space-y-4 mb-8">
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-700">Work with a passionate team dedicated to fighting food insecurity</p>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-700">Flexible work arrangements, including remote options</p>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-700">Competitive benefits and professional development opportunities</p>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-700">Make a meaningful impact on communities across the country</p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-4">
                  <Button className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                    View Open Positions
                  </Button>
                  <Button variant="outline">Volunteer Opportunities</Button>
                </div>
              </div>

              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-400/10 to-pink-400/10 rounded-3xl -z-10 transform -rotate-3" />
                <div className="relative bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
                  <Image
                    src="/placeholder.svg?height=600&width=800"
                    alt="Team working together"
                    width={800}
                    height={600}
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-20 bg-gradient-to-br from-purple-600 to-pink-600 text-white">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">Get in Touch</h2>
              <p className="text-white/80">Have questions about Bridge the Gap? We'd love to hear from you.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 text-center">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4">
                  <MapPin className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Visit Us</h3>
                <p className="text-white/80">
                  123 Impact Way
                  <br />
                  San Francisco, CA 94105
                  <br />
                  United States
                </p>
              </div>

              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 text-center">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Email Us</h3>
                <p className="text-white/80 mb-2">info@bridgethegap.org</p>
                <p className="text-white/80">support@bridgethegap.org</p>
              </div>

              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 text-center">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4">
                  <Phone className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Call Us</h3>
                <p className="text-white/80 mb-2">+1 (555) 123-4567</p>
                <p className="text-white/80">Monday-Friday, 9am-5pm PT</p>
              </div>
            </div>

            <div className="text-center mt-12">
              <Button size="lg" className="bg-white text-purple-700 hover:bg-gray-100">
                Contact Us
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
                  B
                </div>
                <span className="font-bold text-white text-xl">Bridge the Gap</span>
              </div>
              <p className="text-sm text-gray-400 mb-4">
                Connecting skilled volunteers with food distribution networks to create efficient, sustainable community
                support systems.
              </p>
              <div className="flex gap-4">
                {["twitter", "facebook", "instagram", "linkedin"].map((social) => (
                  <a key={social} href="#" className="text-gray-400 hover:text-white transition-colors">
                    <span className="sr-only">{social}</span>
                    <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center">
                      <span className="text-xs">{social[0].toUpperCase()}</span>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            {[
              {
                title: "Platform",
                links: ["How it works", "Features", "Testimonials", "Pricing", "FAQ"],
              },
              {
                title: "Resources",
                links: ["Blog", "Partners", "Community", "Help Center", "Contact Us"],
              },
              {
                title: "Legal",
                links: ["Terms of Service", "Privacy Policy", "Cookie Policy", "Data Processing", "Accessibility"],
              },
            ].map((column, i) => (
              <div key={i}>
                <h3 className="font-bold text-white mb-4">{column.title}</h3>
                <ul className="space-y-2">
                  {column.links.map((link, j) => (
                    <li key={j}>
                      <a href="#" className="text-sm text-gray-400 hover:text-white transition-colors">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-500">© {new Date().getFullYear()} Bridge the Gap. All rights reserved.</p>
            <div className="mt-4 md:mt-0">
              <select className="bg-gray-800 text-gray-300 text-sm rounded-md px-3 py-1.5 border border-gray-700">
                <option>English (US)</option>
                <option>Español</option>
                <option>Français</option>
              </select>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
