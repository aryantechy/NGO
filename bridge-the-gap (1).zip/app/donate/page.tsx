import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, ArrowRight, Truck, Store, ShoppingBag, CheckCircle, HelpCircle } from "lucide-react"
import Image from "next/image"

export default function DonateFoodPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
              B
            </div>
            <span className="font-bold text-xl">Bridge the Gap</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/opportunities" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Find Opportunities
            </Link>
            <Link href="/donate" className="text-sm font-medium text-purple-600 border-b-2 border-purple-600 pb-1">
              Donate Food
            </Link>
            <Link href="/volunteer" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Volunteer Skills
            </Link>
            <Link href="/about" className="text-sm font-medium hover:text-purple-600 transition-colors">
              About Us
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="outline" size="sm">
                Log In
              </Button>
            </Link>
            <Link href="/signup">
              <Button
                className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white"
                size="sm"
              >
                Sign Up
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-pink-50 -z-10" />
          <div className="absolute -right-40 -top-40 w-96 h-96 bg-gradient-to-br from-purple-200/30 to-pink-200/30 rounded-full blur-3xl -z-10" />
          <div className="absolute -left-40 -bottom-40 w-96 h-96 bg-gradient-to-br from-purple-200/30 to-pink-200/30 rounded-full blur-3xl -z-10" />

          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <div className="inline-block px-3 py-1 rounded-full bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 text-sm font-medium mb-4">
                Make a Difference
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Donate Food,{" "}
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-500">
                  Feed Hope
                </span>
              </h1>
              <p className="text-lg text-gray-600 mb-8">
                Your food donations help us bridge the gap between surplus and scarcity. Every donation makes a
                difference in someone's life.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Button
                  className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white"
                  size="lg"
                >
                  Donate Now
                </Button>
                <Button variant="outline" size="lg">
                  Learn How It Works
                </Button>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mt-16">
              {[
                {
                  title: "Donate Food Items",
                  description: "Drop off non-perishable food items at our collection centers or schedule a pickup.",
                  icon: ShoppingBag,
                  color: "from-purple-500 to-purple-700",
                },
                {
                  title: "Schedule a Pickup",
                  description: "We can collect large donations directly from your location at a time that suits you.",
                  icon: Truck,
                  color: "from-pink-500 to-pink-700",
                },
                {
                  title: "Partner Your Business",
                  description: "Businesses can set up regular donation schedules to reduce food waste.",
                  icon: Store,
                  color: "from-purple-500 to-pink-500",
                },
              ].map((item, i) => (
                <div key={i} className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-100 to-pink-100 rounded-xl transform transition-transform group-hover:scale-[1.02] duration-300" />
                  <div className="relative p-8 bg-white rounded-xl border border-gray-100 shadow-sm h-full transition-transform group-hover:translate-y-[-4px] duration-300">
                    <div
                      className={`w-12 h-12 rounded-lg bg-gradient-to-br ${item.color} flex items-center justify-center text-white mb-6`}
                    >
                      <item.icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                    <p className="text-gray-600">{item.description}</p>
                    <div className="mt-6">
                      <Link
                        href="#"
                        className="inline-flex items-center text-sm font-medium text-purple-600 hover:text-purple-800"
                      >
                        Learn more <ArrowRight className="ml-1 w-4 h-4" />
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Donation Options */}
        <section className="py-20 bg-white">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">How to Donate</h2>
              <p className="text-gray-600">
                We've made it easy to donate food through multiple channels. Choose the option that works best for you.
              </p>
            </div>

            <Tabs defaultValue="individual" className="max-w-4xl mx-auto">
              <TabsList className="grid w-full grid-cols-2 mb-8">
                <TabsTrigger
                  value="individual"
                  className="text-base py-3 data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                >
                  Individual Donors
                </TabsTrigger>
                <TabsTrigger
                  value="business"
                  className="text-base py-3 data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                >
                  Business Partners
                </TabsTrigger>
              </TabsList>

              <TabsContent value="individual" className="space-y-8">
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-8">
                  <div className="grid md:grid-cols-2 gap-8 items-center">
                    <div>
                      <h3 className="text-2xl font-bold mb-4">Drop Off Donations</h3>
                      <p className="text-gray-700 mb-6">
                        Bring your non-perishable food items to any of our collection centers. Our volunteers will help
                        you unload and sort your donations.
                      </p>
                      <ul className="space-y-3 mb-6">
                        {[
                          "Non-perishable food items (canned goods, pasta, rice)",
                          "Unopened packaged foods within expiration date",
                          "Baby food and formula",
                          "Personal care items",
                        ].map((item, i) => (
                          <li key={i} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                      <Button className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                        Find Drop-off Locations
                      </Button>
                    </div>
                    <div className="relative rounded-xl overflow-hidden h-64 md:h-auto">
                      <Image
                        src="/placeholder.svg?height=400&width=600"
                        alt="Food donation drop-off"
                        width={600}
                        height={400}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl border border-gray-200 p-8">
                  <div className="grid md:grid-cols-2 gap-8 items-center">
                    <div className="order-2 md:order-1 relative rounded-xl overflow-hidden h-64 md:h-auto">
                      <Image
                        src="/placeholder.svg?height=400&width=600"
                        alt="Food donation pickup"
                        width={600}
                        height={400}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="order-1 md:order-2">
                      <h3 className="text-2xl font-bold mb-4">Schedule a Pickup</h3>
                      <p className="text-gray-700 mb-6">
                        Can't make it to a drop-off location? We can come to you! Schedule a pickup for larger donations
                        or if you're unable to transport items yourself.
                      </p>
                      <div className="space-y-4 mb-6">
                        <div className="flex items-center">
                          <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                            <Calendar className="h-5 w-5 text-purple-600" />
                          </div>
                          <div>
                            <h4 className="font-medium">Flexible Scheduling</h4>
                            <p className="text-sm text-gray-600">Choose a date and time that works for you</p>
                          </div>
                        </div>
                        <div className="flex items-center">
                          <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                            <Truck className="h-5 w-5 text-purple-600" />
                          </div>
                          <div>
                            <h4 className="font-medium">Contactless Pickup</h4>
                            <p className="text-sm text-gray-600">Safe and convenient collection from your doorstep</p>
                          </div>
                        </div>
                      </div>
                      <Button className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                        Schedule a Pickup
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="business" className="space-y-8">
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-8">
                  <div className="grid md:grid-cols-2 gap-8 items-center">
                    <div>
                      <h3 className="text-2xl font-bold mb-4">Business Partnership Program</h3>
                      <p className="text-gray-700 mb-6">
                        Reduce food waste and make a positive impact in your community by partnering with Bridge the
                        Gap. We offer tailored solutions for businesses of all sizes.
                      </p>
                      <ul className="space-y-3 mb-6">
                        {[
                          "Regular scheduled pickups from your location",
                          "Tax benefits for your donations",
                          "Reduce disposal costs and environmental impact",
                          "Enhance your corporate social responsibility profile",
                        ].map((item, i) => (
                          <li key={i} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                      <Button className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                        Become a Partner
                      </Button>
                    </div>
                    <div className="relative rounded-xl overflow-hidden h-64 md:h-auto">
                      <Image
                        src="/placeholder.svg?height=400&width=600"
                        alt="Business food donation"
                        width={600}
                        height={400}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl border border-gray-200 p-8">
                  <h3 className="text-2xl font-bold mb-6 text-center">Our Business Partners</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="flex items-center justify-center p-4">
                        <Image
                          src="/placeholder-logo.svg"
                          width={120}
                          height={60}
                          alt={`Partner logo ${i}`}
                          className="opacity-70 hover:opacity-100 transition-opacity"
                        />
                      </div>
                    ))}
                  </div>
                  <div className="text-center mt-8">
                    <Button variant="outline">View All Partners</Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Donation Form */}
        <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="grid md:grid-cols-2">
                  <div className="bg-gradient-to-br from-purple-600 to-pink-600 p-8 text-white">
                    <h2 className="text-2xl font-bold mb-6">Ready to Donate?</h2>
                    <p className="mb-6">
                      Fill out this form to let us know about your donation. We'll get back to you with the next steps.
                    </p>

                    <div className="space-y-4 mb-8">
                      <div className="flex items-start">
                        <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center mr-3 flex-shrink-0">
                          <span className="font-bold">1</span>
                        </div>
                        <div>
                          <h4 className="font-medium">Tell us about your donation</h4>
                          <p className="text-sm text-white/80">Let us know what you'd like to donate and how much</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center mr-3 flex-shrink-0">
                          <span className="font-bold">2</span>
                        </div>
                        <div>
                          <h4 className="font-medium">Choose your preferred method</h4>
                          <p className="text-sm text-white/80">Drop-off or pickup - whatever works for you</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center mr-3 flex-shrink-0">
                          <span className="font-bold">3</span>
                        </div>
                        <div>
                          <h4 className="font-medium">We'll confirm the details</h4>
                          <p className="text-sm text-white/80">Our team will reach out to finalize arrangements</p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white/10 rounded-lg p-4">
                      <h4 className="font-medium flex items-center mb-2">
                        <HelpCircle className="h-4 w-4 mr-2" /> Need assistance?
                      </h4>
                      <p className="text-sm mb-3">Our team is here to help with any questions about donations.</p>
                      <div className="text-sm">
                        <div className="mb-1">📧 donations@bridgethegap.org</div>
                        <div>📞 (555) 123-4567</div>
                      </div>
                    </div>
                  </div>

                  <div className="p-8">
                    <h3 className="text-xl font-bold mb-6">Donation Information</h3>
                    <form className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label htmlFor="first-name" className="text-sm font-medium">
                            First name
                          </label>
                          <Input id="first-name" placeholder="Enter your first name" />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="last-name" className="text-sm font-medium">
                            Last name
                          </label>
                          <Input id="last-name" placeholder="Enter your last name" />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="email" className="text-sm font-medium">
                          Email
                        </label>
                        <Input id="email" type="email" placeholder="Enter your email" />
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="phone" className="text-sm font-medium">
                          Phone number
                        </label>
                        <Input id="phone" placeholder="Enter your phone number" />
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="donation-type" className="text-sm font-medium">
                          Donation method
                        </label>
                        <select
                          id="donation-type"
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          <option value="">Select a method</option>
                          <option value="drop-off">Drop-off at location</option>
                          <option value="pickup">Schedule a pickup</option>
                          <option value="business">Business partnership</option>
                        </select>
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="donation-details" className="text-sm font-medium">
                          Donation details
                        </label>
                        <Textarea
                          id="donation-details"
                          placeholder="Please describe what you'd like to donate (types of items, quantities, etc.)"
                          rows={4}
                        />
                      </div>

                      <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                        Submit Donation Request
                      </Button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20 bg-white">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
              <p className="text-gray-600">
                Have questions about donating food? Find answers to common questions below.
              </p>
            </div>

            <div className="max-w-3xl mx-auto space-y-6">
              {[
                {
                  question: "What types of food can I donate?",
                  answer:
                    "We accept non-perishable food items such as canned goods, pasta, rice, cereal, and other packaged foods that are unopened and within their expiration date. We also accept fresh produce, dairy, and frozen foods at certain locations with proper refrigeration facilities.",
                },
                {
                  question: "How do I know my donation is going to those in need?",
                  answer:
                    "Bridge the Gap works directly with local food banks, shelters, and community organizations to ensure donations reach those who need them most. We maintain transparent tracking systems and can provide reports on where your donations were distributed upon request.",
                },
                {
                  question: "Are my food donations tax-deductible?",
                  answer:
                    "Yes, food donations are tax-deductible. We provide donation receipts for all contributions that can be used for tax purposes. Please consult with your tax advisor for specific information regarding your situation.",
                },
                {
                  question: "Can I donate food that's close to its expiration date?",
                  answer:
                    "Yes, we accept food that is close to but not past its expiration date. Our distribution system prioritizes these items to ensure they reach recipients quickly. However, we cannot accept expired food items for safety reasons.",
                },
                {
                  question: "How can my business become a regular food donor?",
                  answer:
                    "Businesses can join our partnership program by filling out the business partner form or contacting our partnership team directly. We'll work with you to establish a regular donation schedule that minimizes food waste and maximizes community impact.",
                },
              ].map((faq, i) => (
                <div key={i} className="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors">
                  <h3 className="text-lg font-bold mb-3 flex items-start">
                    <HelpCircle className="h-5 w-5 text-purple-600 mr-2 flex-shrink-0 mt-0.5" />
                    {faq.question}
                  </h3>
                  <p className="text-gray-700 pl-7">{faq.answer}</p>
                </div>
              ))}
            </div>

            <div className="text-center mt-10">
              <p className="text-gray-600 mb-4">Don't see your question here?</p>
              <Button variant="outline">Contact Support</Button>
            </div>
          </div>
        </section>

        {/* Impact Section */}
        <section className="py-20 bg-gradient-to-br from-purple-600 to-pink-600 text-white">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">Your Donation Makes an Impact</h2>
              <p className="text-white/80">
                Every food donation helps us bridge the gap between surplus and scarcity. See the difference we're
                making together.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              {[
                { value: "250K", label: "Meals Distributed" },
                { value: "10K+", label: "Families Helped" },
                { value: "85%", label: "Reduction in Food Waste" },
              ].map((stat, i) => (
                <div key={i} className="text-center bg-white/10 rounded-xl p-8 backdrop-blur-sm">
                  <div className="text-4xl font-bold mb-2">{stat.value}</div>
                  <p className="text-white/80">{stat.label}</p>
                </div>
              ))}
            </div>

            <div className="mt-16 text-center">
              <Button size="lg" className="bg-white text-purple-700 hover:bg-gray-100">
                Start Donating Today
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
                  B
                </div>
                <span className="font-bold text-white text-xl">Bridge the Gap</span>
              </div>
              <p className="text-sm text-gray-400 mb-4">
                Connecting skilled volunteers with food distribution networks to create efficient, sustainable community
                support systems.
              </p>
              <div className="flex gap-4">
                {["twitter", "facebook", "instagram", "linkedin"].map((social) => (
                  <a key={social} href="#" className="text-gray-400 hover:text-white transition-colors">
                    <span className="sr-only">{social}</span>
                    <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center">
                      <span className="text-xs">{social[0].toUpperCase()}</span>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            {[
              {
                title: "Platform",
                links: ["How it works", "Features", "Testimonials", "Pricing", "FAQ"],
              },
              {
                title: "Resources",
                links: ["Blog", "Partners", "Community", "Help Center", "Contact Us"],
              },
              {
                title: "Legal",
                links: ["Terms of Service", "Privacy Policy", "Cookie Policy", "Data Processing", "Accessibility"],
              },
            ].map((column, i) => (
              <div key={i}>
                <h3 className="font-bold text-white mb-4">{column.title}</h3>
                <ul className="space-y-2">
                  {column.links.map((link, j) => (
                    <li key={j}>
                      <a href="#" className="text-sm text-gray-400 hover:text-white transition-colors">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-500">© {new Date().getFullYear()} Bridge the Gap. All rights reserved.</p>
            <div className="mt-4 md:mt-0">
              <select className="bg-gray-800 text-gray-300 text-sm rounded-md px-3 py-1.5 border border-gray-700">
                <option>English (US)</option>
                <option>Español</option>
                <option>Français</option>
              </select>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
