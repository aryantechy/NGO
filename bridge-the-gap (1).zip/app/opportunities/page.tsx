import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  Filter,
  MapPin,
  Clock,
  Briefcase,
  Heart,
  ChevronDown,
  ArrowUpDown,
  Grid,
  List,
  Calendar,
} from "lucide-react"
import Image from "next/image"

export default function OpportunitiesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
              B
            </div>
            <span className="font-bold text-xl">Bridge the Gap</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link
              href="/opportunities"
              className="text-sm font-medium text-purple-600 border-b-2 border-purple-600 pb-1"
            >
              Find Opportunities
            </Link>
            <Link href="/donate" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Donate Food
            </Link>
            <Link href="/volunteer" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Volunteer Skills
            </Link>
            <Link href="/about" className="text-sm font-medium hover:text-purple-600 transition-colors">
              About Us
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-200 to-pink-200 flex items-center justify-center">
              <span className="font-medium text-purple-800">JS</span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 bg-gray-50">
        {/* Search Header */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white py-12">
          <div className="container">
            <h1 className="text-3xl font-bold mb-6">Find Volunteering Opportunities</h1>
            <div className="bg-white rounded-xl p-4 shadow-lg">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                  <Input placeholder="Search by skill, title, or organization" className="pl-10 bg-gray-50 border-0" />
                </div>
                <div className="relative w-full md:w-48">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                  <Input placeholder="Location" className="pl-10 bg-gray-50 border-0" />
                </div>
                <Button className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                  Search
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="container py-8">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Filters Sidebar */}
            <div className="w-full lg:w-64 space-y-6">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="font-medium text-lg mb-4 flex items-center">
                  <Filter className="mr-2 h-4 w-4" /> Filters
                </h3>

                <div className="space-y-6">
                  {/* Opportunity Type */}
                  <div>
                    <h4 className="text-sm font-medium mb-3">Opportunity Type</h4>
                    <div className="space-y-2">
                      {["Remote", "In-person", "Hybrid"].map((type) => (
                        <div key={type} className="flex items-center">
                          <input
                            type="checkbox"
                            id={`type-${type}`}
                            className="h-4 w-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                          />
                          <label htmlFor={`type-${type}`} className="ml-2 text-sm text-gray-600">
                            {type}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Skills */}
                  <div>
                    <h4 className="text-sm font-medium mb-3">Skills</h4>
                    <div className="space-y-2">
                      {["Logistics", "Technology", "Marketing", "Food Safety", "Management"].map((skill) => (
                        <div key={skill} className="flex items-center">
                          <input
                            type="checkbox"
                            id={`skill-${skill}`}
                            className="h-4 w-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                          />
                          <label htmlFor={`skill-${skill}`} className="ml-2 text-sm text-gray-600">
                            {skill}
                          </label>
                        </div>
                      ))}
                    </div>
                    <Button variant="link" className="text-purple-600 p-0 h-auto text-sm mt-2">
                      Show more
                    </Button>
                  </div>

                  {/* Commitment */}
                  <div>
                    <h4 className="text-sm font-medium mb-3">Time Commitment</h4>
                    <div className="space-y-2">
                      {["One-time", "Weekly", "Monthly", "Flexible"].map((time) => (
                        <div key={time} className="flex items-center">
                          <input
                            type="checkbox"
                            id={`time-${time}`}
                            className="h-4 w-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                          />
                          <label htmlFor={`time-${time}`} className="ml-2 text-sm text-gray-600">
                            {time}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Distance */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-medium">Distance</h4>
                      <span className="text-xs text-gray-500">25 miles</span>
                    </div>
                    <Slider defaultValue={[25]} max={100} step={5} className="py-4" />
                  </div>

                  {/* Urgent Needs */}
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="urgent"
                      className="h-4 w-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                    />
                    <label htmlFor="urgent" className="ml-2 text-sm font-medium text-gray-900">
                      Urgent Needs Only
                    </label>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                    Apply Filters
                  </Button>
                  <Button variant="outline" className="w-full">
                    Reset
                  </Button>
                </div>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100">
                <h3 className="font-medium text-lg mb-2">Need Help?</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Not sure which opportunity is right for you? Our team can help match your skills.
                </p>
                <Button variant="outline" className="w-full">
                  Contact Support
                </Button>
              </div>
            </div>

            {/* Main Content */}
            <div className="flex-1">
              <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <h2 className="text-xl font-bold">120 Opportunities Found</h2>
                    <p className="text-sm text-gray-500">Based on your search criteria</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="sm" className="h-8 gap-1">
                        <ArrowUpDown className="h-4 w-4" />
                        Sort
                      </Button>
                      <div className="flex border rounded-md overflow-hidden">
                        <Button variant="ghost" size="icon" className="h-8 w-8 rounded-none border-r">
                          <Grid className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 rounded-none bg-gray-50">
                          <List className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <Tabs defaultValue="all" className="mb-6">
                <TabsList className="bg-white border">
                  <TabsTrigger
                    value="all"
                    className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                  >
                    All Opportunities
                  </TabsTrigger>
                  <TabsTrigger
                    value="saved"
                    className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                  >
                    Saved
                  </TabsTrigger>
                  <TabsTrigger
                    value="applied"
                    className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                  >
                    Applied
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="all" className="mt-4">
                  <div className="grid md:grid-cols-2 gap-6">
                    {[
                      {
                        title: "Food Inventory Manager",
                        organization: "Community Food Bank",
                        location: "San Francisco, CA",
                        type: "Remote",
                        skills: ["Database Management", "Inventory Systems"],
                        urgent: true,
                        posted: "2 days ago",
                        commitment: "5-10 hrs/week",
                      },
                      {
                        title: "Delivery Route Optimizer",
                        organization: "Meals on Wheels",
                        location: "Chicago, IL",
                        type: "Hybrid",
                        skills: ["Logistics", "Route Planning"],
                        urgent: false,
                        posted: "1 week ago",
                        commitment: "3-5 hrs/week",
                      },
                      {
                        title: "Mobile App Developer",
                        organization: "Food Rescue Network",
                        location: "Austin, TX",
                        type: "Remote",
                        skills: ["React Native", "API Integration"],
                        urgent: false,
                        posted: "3 days ago",
                        commitment: "10-15 hrs/week",
                      },
                      {
                        title: "Marketing Strategist",
                        organization: "Feeding Families",
                        location: "New York, NY",
                        type: "In-person",
                        skills: ["Social Media", "Content Creation"],
                        urgent: true,
                        posted: "Just now",
                        commitment: "Flexible",
                      },
                    ].map((item, i) => (
                      <div
                        key={i}
                        className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden group hover:shadow-md transition-shadow duration-300"
                      >
                        <div className="h-40 bg-gradient-to-br from-purple-400/10 to-pink-400/10 relative">
                          <div className="absolute inset-0 flex items-center justify-center">
                            <Image
                              src="/placeholder.svg?height=200&width=400"
                              alt={item.organization}
                              width={400}
                              height={200}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          {item.urgent && (
                            <div className="absolute top-4 right-4 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center">
                              <Clock className="w-3 h-3 mr-1" /> Urgent Need
                            </div>
                          )}
                        </div>
                        <div className="p-6">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-bold text-lg mb-1 group-hover:text-purple-600 transition-colors">
                                {item.title}
                              </h3>
                              <p className="text-gray-600 text-sm">{item.organization}</p>
                            </div>
                            <Button variant="ghost" size="icon" className="rounded-full h-8 w-8">
                              <Heart className="h-4 w-4" />
                              <span className="sr-only">Save</span>
                            </Button>
                          </div>
                          <div className="mt-4 flex items-center text-sm text-gray-500">
                            <MapPin className="w-4 h-4 mr-1" />
                            <span>{item.location}</span>
                            <span className="mx-2">•</span>
                            <span>{item.type}</span>
                          </div>
                          <div className="mt-2 flex items-center text-sm text-gray-500">
                            <Calendar className="w-4 h-4 mr-1" />
                            <span>{item.commitment}</span>
                            <span className="mx-2">•</span>
                            <span>Posted {item.posted}</span>
                          </div>
                          <div className="mt-4 flex flex-wrap gap-2">
                            {item.skills.map((skill, j) => (
                              <span
                                key={j}
                                className="inline-block bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded-full"
                              >
                                {skill}
                              </span>
                            ))}
                          </div>
                          <div className="mt-6">
                            <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                              View Details
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-8 flex justify-center">
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="icon" className="h-8 w-8">
                        <span className="sr-only">Previous page</span>
                        <ChevronDown className="h-4 w-4 rotate-90" />
                      </Button>
                      {[1, 2, 3, 4, 5].map((page) => (
                        <Button
                          key={page}
                          variant={page === 1 ? "default" : "outline"}
                          size="sm"
                          className={page === 1 ? "bg-purple-600 hover:bg-purple-700" : ""}
                        >
                          {page}
                        </Button>
                      ))}
                      <Button variant="outline" size="icon" className="h-8 w-8">
                        <span className="sr-only">Next page</span>
                        <ChevronDown className="h-4 w-4 -rotate-90" />
                      </Button>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="saved" className="mt-4">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
                    <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Heart className="h-8 w-8 text-purple-600" />
                    </div>
                    <h3 className="text-lg font-medium mb-2">No saved opportunities yet</h3>
                    <p className="text-gray-500 mb-6">Save opportunities you're interested in to view them later</p>
                    <Button variant="outline">Browse Opportunities</Button>
                  </div>
                </TabsContent>

                <TabsContent value="applied" className="mt-4">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
                    <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Briefcase className="h-8 w-8 text-purple-600" />
                    </div>
                    <h3 className="text-lg font-medium mb-2">No applications yet</h3>
                    <p className="text-gray-500 mb-6">When you apply for opportunities, they'll appear here</p>
                    <Button variant="outline">Browse Opportunities</Button>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-8">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
                B
              </div>
              <span className="font-bold text-white text-xl">Bridge the Gap</span>
            </div>
            <p className="text-sm text-gray-500">© {new Date().getFullYear()} Bridge the Gap. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
