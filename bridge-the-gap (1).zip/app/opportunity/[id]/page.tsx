import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  MapPin,
  Clock,
  Calendar,
  Briefcase,
  Heart,
  Share2,
  ArrowLeft,
  CheckCircle,
  Users,
  Award,
  Building,
} from "lucide-react"
import Image from "next/image"

export default function OpportunityDetailPage() {
  // Mock data for the opportunity
  const opportunity = {
    id: "1",
    title: "Food Inventory Manager",
    organization: "Community Food Bank",
    location: "San Francisco, CA",
    type: "Remote",
    skills: ["Database Management", "Inventory Systems", "Excel", "Data Analysis"],
    urgent: true,
    posted: "2 days ago",
    commitment: "5-10 hrs/week",
    duration: "3 months",
    description:
      "We're looking for a skilled volunteer to help us optimize our food inventory management system. You'll work with our team to track donations, manage stock levels, and ensure efficient distribution to those in need.",
    responsibilities: [
      "Develop and maintain inventory tracking systems",
      "Generate weekly reports on food stock levels",
      "Identify opportunities for process improvement",
      "Train staff on inventory management best practices",
      "Coordinate with food donors and distribution centers",
    ],
    requirements: [
      "Experience with inventory management systems",
      "Strong Excel or database management skills",
      "Excellent analytical and problem-solving abilities",
      "Good communication skills",
      "Ability to commit 5-10 hours per week for at least 3 months",
    ],
    impact:
      "Your contribution will help us reduce food waste by 30% and ensure that we can serve an additional 500 families each month through more efficient inventory management.",
    applicationProcess:
      "After applying, you'll have a brief video call with our volunteer coordinator to discuss your skills and availability. If it's a good match, we'll provide training and get you started right away.",
    contactPerson: "Sarah Johnson",
    contactTitle: "Volunteer Coordinator",
    contactEmail: "sjohnson@communityfoodbank.org",
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
              B
            </div>
            <span className="font-bold text-xl">Bridge the Gap</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link
              href="/opportunities"
              className="text-sm font-medium text-purple-600 border-b-2 border-purple-600 pb-1"
            >
              Find Opportunities
            </Link>
            <Link href="/donate" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Donate Food
            </Link>
            <Link href="/volunteer" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Volunteer Skills
            </Link>
            <Link href="/about" className="text-sm font-medium hover:text-purple-600 transition-colors">
              About Us
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-200 to-pink-200 flex items-center justify-center">
              <span className="font-medium text-purple-800">JS</span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 bg-gray-50">
        <div className="container py-8">
          <Link
            href="/opportunities"
            className="inline-flex items-center text-sm text-gray-600 hover:text-purple-600 mb-6"
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to opportunities
          </Link>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Header */}
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="h-48 bg-gradient-to-br from-purple-400/10 to-pink-400/10 relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Image
                      src="/placeholder.svg?height=300&width=800"
                      alt={opportunity.organization}
                      width={800}
                      height={300}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {opportunity.urgent && (
                    <div className="absolute top-4 right-4 bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center">
                      <Clock className="w-3 h-3 mr-1" /> Urgent Need
                    </div>
                  )}
                </div>

                <div className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                    <div>
                      <h1 className="text-2xl font-bold">{opportunity.title}</h1>
                      <div className="flex items-center mt-1">
                        <Building className="h-4 w-4 text-gray-500 mr-1" />
                        <span className="text-gray-700">{opportunity.organization}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="gap-1">
                        <Heart className="h-4 w-4" />
                        Save
                      </Button>
                      <Button variant="outline" size="sm" className="gap-1">
                        <Share2 className="h-4 w-4" />
                        Share
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-4 border-y">
                    <div>
                      <div className="text-sm text-gray-500 mb-1 flex items-center">
                        <MapPin className="h-4 w-4 mr-1" /> Location
                      </div>
                      <div className="font-medium">{opportunity.location}</div>
                      <div className="text-sm text-purple-600">{opportunity.type}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500 mb-1 flex items-center">
                        <Clock className="h-4 w-4 mr-1" /> Commitment
                      </div>
                      <div className="font-medium">{opportunity.commitment}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500 mb-1 flex items-center">
                        <Calendar className="h-4 w-4 mr-1" /> Duration
                      </div>
                      <div className="font-medium">{opportunity.duration}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500 mb-1 flex items-center">
                        <Briefcase className="h-4 w-4 mr-1" /> Posted
                      </div>
                      <div className="font-medium">{opportunity.posted}</div>
                    </div>
                  </div>

                  <div className="mt-4">
                    <div className="text-sm font-medium mb-2">Skills Needed:</div>
                    <div className="flex flex-wrap gap-2">
                      {opportunity.skills.map((skill, i) => (
                        <Badge key={i} variant="outline" className="bg-purple-50 text-purple-700 hover:bg-purple-100">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Tabs */}
              <div className="bg-white rounded-xl shadow-sm">
                <Tabs defaultValue="details">
                  <TabsList className="w-full border-b rounded-none p-0">
                    <TabsTrigger
                      value="details"
                      className="rounded-none flex-1 py-3 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-700 data-[state=active]:shadow-none"
                    >
                      Details
                    </TabsTrigger>
                    <TabsTrigger
                      value="organization"
                      className="rounded-none flex-1 py-3 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-700 data-[state=active]:shadow-none"
                    >
                      Organization
                    </TabsTrigger>
                    <TabsTrigger
                      value="reviews"
                      className="rounded-none flex-1 py-3 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-700 data-[state=active]:shadow-none"
                    >
                      Reviews
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="details" className="p-6 space-y-6">
                    <div>
                      <h2 className="text-lg font-bold mb-3">Description</h2>
                      <p className="text-gray-700">{opportunity.description}</p>
                    </div>

                    <div>
                      <h2 className="text-lg font-bold mb-3">Responsibilities</h2>
                      <ul className="space-y-2">
                        {opportunity.responsibilities.map((item, i) => (
                          <li key={i} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h2 className="text-lg font-bold mb-3">Requirements</h2>
                      <ul className="space-y-2">
                        {opportunity.requirements.map((item, i) => (
                          <li key={i} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl border border-purple-100">
                      <h2 className="text-lg font-bold mb-3 flex items-center">
                        <Award className="h-5 w-5 mr-2 text-purple-600" />
                        Impact of Your Contribution
                      </h2>
                      <p className="text-gray-700">{opportunity.impact}</p>
                    </div>

                    <div>
                      <h2 className="text-lg font-bold mb-3">Application Process</h2>
                      <p className="text-gray-700">{opportunity.applicationProcess}</p>
                    </div>
                  </TabsContent>

                  <TabsContent value="organization" className="p-6 space-y-6">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-pink-100 rounded-lg flex items-center justify-center">
                        <Building className="h-8 w-8 text-purple-600" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold">{opportunity.organization}</h2>
                        <p className="text-gray-600">Non-profit organization</p>
                      </div>
                    </div>

                    <p className="text-gray-700">
                      Community Food Bank is dedicated to fighting hunger in the San Francisco Bay Area. We collect and
                      distribute food to those in need, working with local partners to ensure everyone has access to
                      nutritious meals.
                    </p>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">Founded</div>
                        <div className="font-medium">1985</div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">Location</div>
                        <div className="font-medium">San Francisco, CA</div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">People Served</div>
                        <div className="font-medium">50,000+ monthly</div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="text-sm text-gray-500 mb-1">Active Volunteers</div>
                        <div className="font-medium">250+</div>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-md font-bold mb-3">Other Opportunities from this Organization</h3>
                      <div className="space-y-3">
                        {["Delivery Driver", "Nutrition Educator", "Grant Writer"].map((title, i) => (
                          <div
                            key={i}
                            className="flex justify-between items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                          >
                            <div>
                              <div className="font-medium">{title}</div>
                              <div className="text-sm text-gray-500">San Francisco, CA</div>
                            </div>
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="reviews" className="p-6 space-y-6">
                    <div className="flex items-center gap-4">
                      <div className="bg-purple-100 text-purple-700 text-2xl font-bold w-16 h-16 rounded-lg flex items-center justify-center">
                        4.8
                      </div>
                      <div>
                        <div className="font-bold">Excellent</div>
                        <div className="text-sm text-gray-500">Based on 24 volunteer reviews</div>
                      </div>
                    </div>

                    <div className="space-y-6">
                      {[
                        {
                          name: "Michael T.",
                          role: "Database Administrator",
                          date: "3 months ago",
                          rating: 5,
                          comment:
                            "Great experience working with the Community Food Bank team. They were very organized and appreciative of my contributions. I felt my skills were put to good use and made a real difference.",
                        },
                        {
                          name: "Jessica L.",
                          role: "Data Analyst",
                          date: "6 months ago",
                          rating: 4,
                          comment:
                            "Rewarding volunteer opportunity that allowed me to use my professional skills for a good cause. The team was supportive and the work had a clear impact on their operations.",
                        },
                      ].map((review, i) => (
                        <div key={i} className="border-t pt-6">
                          <div className="flex justify-between items-start">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-200 to-pink-200 flex items-center justify-center">
                                <span className="font-medium text-purple-800">{review.name[0]}</span>
                              </div>
                              <div>
                                <div className="font-medium">{review.name}</div>
                                <div className="text-sm text-gray-500">{review.role}</div>
                              </div>
                            </div>
                            <div className="text-sm text-gray-500">{review.date}</div>
                          </div>
                          <div className="flex items-center mt-2">
                            {Array(5)
                              .fill(0)
                              .map((_, i) => (
                                <svg
                                  key={i}
                                  className={`w-4 h-4 ${i < review.rating ? "text-yellow-400" : "text-gray-300"}`}
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                              ))}
                          </div>
                          <p className="mt-3 text-gray-700">{review.comment}</p>
                        </div>
                      ))}
                    </div>

                    <Button variant="outline" className="w-full">
                      View All Reviews
                    </Button>
                  </TabsContent>
                </Tabs>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-bold mb-4">Apply for this Opportunity</h2>
                <p className="text-gray-600 mb-6">
                  Ready to make an impact with your skills? Apply now to connect with {opportunity.organization}.
                </p>
                <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white mb-4">
                  Apply Now
                </Button>
                <div className="text-center text-sm text-gray-500">
                  <span className="flex items-center justify-center gap-1 mb-1">
                    <Users className="h-4 w-4" />
                    12 people have applied
                  </span>
                  Application takes about 5 minutes
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-bold mb-4">Contact Person</h2>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-200 to-pink-200 flex items-center justify-center">
                    <span className="font-medium text-purple-800">{opportunity.contactPerson[0]}</span>
                  </div>
                  <div>
                    <div className="font-medium">{opportunity.contactPerson}</div>
                    <div className="text-sm text-gray-500">{opportunity.contactTitle}</div>
                  </div>
                </div>
                <Button variant="outline" className="w-full mb-2">
                  Send Message
                </Button>
                <Button variant="ghost" className="w-full text-gray-600">
                  {opportunity.contactEmail}
                </Button>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100">
                <h2 className="text-lg font-bold mb-3">Similar Opportunities</h2>
                <div className="space-y-4">
                  {[
                    {
                      title: "Database Administrator",
                      organization: "Food for All",
                      location: "Remote",
                    },
                    {
                      title: "Inventory Specialist",
                      organization: "Hunger Relief Network",
                      location: "Boston, MA",
                    },
                    {
                      title: "Data Analyst",
                      organization: "Community Pantry",
                      location: "Remote",
                    },
                  ].map((item, i) => (
                    <div key={i} className="bg-white rounded-lg p-3 shadow-sm hover:shadow-md transition-shadow">
                      <h3 className="font-medium text-purple-700">{item.title}</h3>
                      <div className="text-sm text-gray-600">{item.organization}</div>
                      <div className="text-xs text-gray-500 mt-1">{item.location}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-8">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
                B
              </div>
              <span className="font-bold text-white text-xl">Bridge the Gap</span>
            </div>
            <p className="text-sm text-gray-500">© {new Date().getFullYear()} Bridge the Gap. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
