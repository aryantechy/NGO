import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronRight, ArrowRight, Heart, Clock, MapPin, Users, Briefcase } from "lucide-react"
import Image from "next/image"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
              B
            </div>
            <span className="font-bold text-xl">Bridge the Gap</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/opportunities" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Find Opportunities
            </Link>
            <Link href="/donate" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Donate Food
            </Link>
            <Link href="/volunteer" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Volunteer Skills
            </Link>
            <Link href="/about" className="text-sm font-medium hover:text-purple-600 transition-colors">
              About Us
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="outline" size="sm">
                Log In
              </Button>
            </Link>
            <Link href="/signup">
              <Button
                className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white"
                size="sm"
              >
                Sign Up
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-pink-50 -z-10" />
        <div className="absolute -right-40 -top-40 w-96 h-96 bg-gradient-to-br from-purple-200/30 to-pink-200/30 rounded-full blur-3xl -z-10" />
        <div className="absolute -left-40 -bottom-40 w-96 h-96 bg-gradient-to-br from-purple-200/30 to-pink-200/30 rounded-full blur-3xl -z-10" />

        <div className="container grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="inline-block px-3 py-1 rounded-full bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 text-sm font-medium">
              Connect • Contribute • Change
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Share Your Skills,{" "}
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-500">
                Feed a Community
              </span>
            </h1>
            <p className="text-lg text-gray-600">
              Bridge the Gap connects skilled volunteers with food distribution networks to create efficient,
              sustainable community support systems.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button
                className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white"
                size="lg"
              >
                Find Opportunities <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
              <Button variant="outline" size="lg">
                How It Works
              </Button>
            </div>
            <div className="flex items-center gap-4 pt-4">
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="w-8 h-8 rounded-full border-2 border-white bg-gradient-to-br from-purple-400 to-pink-400"
                  />
                ))}
              </div>
              <p className="text-sm text-gray-600">
                <span className="font-bold text-gray-900">1,200+</span> volunteers already joined
              </p>
            </div>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-400/10 to-pink-400/10 rounded-3xl -z-10 transform rotate-3" />
            <div className="relative bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
              <Image
                src="/placeholder.svg?height=600&width=800"
                alt="Volunteers working together"
                width={800}
                height={600}
                className="w-full h-auto"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                <p className="text-white font-medium">Skill-based volunteers making a difference</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold mb-4">How Bridge the Gap Works</h2>
            <p className="text-gray-600">
              Our platform connects three key groups to create an efficient food distribution system powered by skilled
              volunteers.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Food Donors",
                description:
                  "Businesses and individuals can donate surplus food through our platform, reducing waste and helping communities.",
                icon: Heart,
                color: "from-purple-500 to-purple-700",
              },
              {
                title: "Skilled Volunteers",
                description:
                  "Contribute your professional skills to help manage, distribute, and support food assistance programs.",
                icon: Briefcase,
                color: "from-pink-500 to-pink-700",
              },
              {
                title: "Food Recipients",
                description:
                  "Easily find available food resources near you with real-time inventory tracking and notifications.",
                icon: Users,
                color: "from-purple-500 to-pink-500",
              },
            ].map((item, i) => (
              <div key={i} className="relative group">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-100 to-pink-100 rounded-xl transform transition-transform group-hover:scale-[1.02] duration-300" />
                <div className="relative p-8 bg-white rounded-xl border border-gray-100 shadow-sm h-full transition-transform group-hover:translate-y-[-4px] duration-300">
                  <div
                    className={`w-12 h-12 rounded-lg bg-gradient-to-br ${item.color} flex items-center justify-center text-white mb-6`}
                  >
                    <item.icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                  <p className="text-gray-600">{item.description}</p>
                  <div className="mt-6">
                    <Link
                      href="#"
                      className="inline-flex items-center text-sm font-medium text-purple-600 hover:text-purple-800"
                    >
                      Learn more <ArrowRight className="ml-1 w-4 h-4" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Opportunities */}
      <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="container">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold">Featured Opportunities</h2>
            <Link href="/opportunities" className="text-purple-600 font-medium flex items-center hover:text-purple-800">
              View all <ChevronRight className="ml-1 w-4 h-4" />
            </Link>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Food Inventory Manager",
                organization: "Community Food Bank",
                location: "San Francisco, CA",
                type: "Remote",
                skills: ["Database Management", "Inventory Systems"],
                urgent: true,
              },
              {
                title: "Delivery Route Optimizer",
                organization: "Meals on Wheels",
                location: "Chicago, IL",
                type: "Hybrid",
                skills: ["Logistics", "Route Planning"],
                urgent: false,
              },
              {
                title: "Mobile App Developer",
                organization: "Food Rescue Network",
                location: "Austin, TX",
                type: "Remote",
                skills: ["React Native", "API Integration"],
                urgent: false,
              },
            ].map((item, i) => (
              <div
                key={i}
                className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden group hover:shadow-md transition-shadow duration-300"
              >
                <div className="h-40 bg-gradient-to-br from-purple-400/10 to-pink-400/10 relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Image
                      src="/placeholder.svg?height=200&width=400"
                      alt={item.organization}
                      width={400}
                      height={200}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {item.urgent && (
                    <div className="absolute top-4 right-4 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center">
                      <Clock className="w-3 h-3 mr-1" /> Urgent Need
                    </div>
                  )}
                </div>
                <div className="p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-bold text-lg mb-1 group-hover:text-purple-600 transition-colors">
                        {item.title}
                      </h3>
                      <p className="text-gray-600 text-sm">{item.organization}</p>
                    </div>
                    <Button variant="ghost" size="icon" className="rounded-full h-8 w-8">
                      <Heart className="h-4 w-4" />
                      <span className="sr-only">Save</span>
                    </Button>
                  </div>
                  <div className="mt-4 flex items-center text-sm text-gray-500">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>{item.location}</span>
                    <span className="mx-2">•</span>
                    <span>{item.type}</span>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {item.skills.map((skill, j) => (
                      <span
                        key={j}
                        className="inline-block bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded-full"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                  <div className="mt-6">
                    <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                      Apply Now
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Impact Stats */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold mb-4">Our Impact</h2>
            <p className="text-gray-600">Together, we're making a difference in communities across the country.</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: "10K+", label: "Volunteers" },
              { value: "500+", label: "Partner Organizations" },
              { value: "250K", label: "Meals Distributed" },
              { value: "85%", label: "Reduction in Food Waste" },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-purple-100 to-pink-100 mb-4">
                  <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-500">
                    {stat.value}
                  </span>
                </div>
                <p className="font-medium text-gray-800">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-purple-600 to-pink-600 text-white">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to make an impact with your skills?</h2>
            <p className="text-xl opacity-90 mb-8">
              Join our community of skilled volunteers and help bridge the gap between food surplus and those in need.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button size="lg" className="bg-white text-purple-700 hover:bg-gray-100">
                Sign Up Now
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
                  B
                </div>
                <span className="font-bold text-white text-xl">Bridge the Gap</span>
              </div>
              <p className="text-sm text-gray-400 mb-4">
                Connecting skilled volunteers with food distribution networks to create efficient, sustainable community
                support systems.
              </p>
              <div className="flex gap-4">
                {["twitter", "facebook", "instagram", "linkedin"].map((social) => (
                  <a key={social} href="#" className="text-gray-400 hover:text-white transition-colors">
                    <span className="sr-only">{social}</span>
                    <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center">
                      <span className="text-xs">{social[0].toUpperCase()}</span>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            {[
              {
                title: "Platform",
                links: ["How it works", "Features", "Testimonials", "Pricing", "FAQ"],
              },
              {
                title: "Resources",
                links: ["Blog", "Partners", "Community", "Help Center", "Contact Us"],
              },
              {
                title: "Legal",
                links: ["Terms of Service", "Privacy Policy", "Cookie Policy", "Data Processing", "Accessibility"],
              },
            ].map((column, i) => (
              <div key={i}>
                <h3 className="font-bold text-white mb-4">{column.title}</h3>
                <ul className="space-y-2">
                  {column.links.map((link, j) => (
                    <li key={j}>
                      <a href="#" className="text-sm text-gray-400 hover:text-white transition-colors">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-500">© {new Date().getFullYear()} Bridge the Gap. All rights reserved.</p>
            <div className="mt-4 md:mt-0">
              <select className="bg-gray-800 text-gray-300 text-sm rounded-md px-3 py-1.5 border border-gray-700">
                <option>English (US)</option>
                <option>Español</option>
                <option>Français</option>
              </select>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
