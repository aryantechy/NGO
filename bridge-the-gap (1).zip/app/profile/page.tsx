import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  User,
  Settings,
  LogOut,
  MapPin,
  Clock,
  Calendar,
  Award,
  Heart,
  CheckCircle,
  Star,
  Mail,
  Phone,
} from "lucide-react"
import Image from "next/image"

export default function ProfilePage() {
  // Mock user data
  const user = {
    name: "Jessica Smith",
    title: "UX Designer & Food Enthusiast",
    location: "San Francisco, CA",
    email: "jessica@example.com",
    phone: "(555) 123-4567",
    bio: "Passionate about using my design skills to help organizations fighting food insecurity. I believe everyone deserves access to nutritious food and I'm committed to contributing my professional expertise to make that happen.",
    skills: ["UX/UI Design", "User Research", "Prototyping", "Figma", "Adobe Creative Suite", "HTML/CSS"],
    availability: "10-15 hours/week",
    preferredLocation: "Remote or San Francisco Bay Area",
    interests: ["Food Security", "Sustainability", "Education", "Community Development"],
    volunteeredHours: 87,
    impactPoints: 450,
    completedOpportunities: 5,
    savedOpportunities: 8,
    upcomingOpportunities: [
      {
        title: "UX Audit for Food Donation App",
        organization: "Food Rescue Network",
        date: "May 15, 2023",
        time: "10:00 AM - 12:00 PM",
        location: "Remote",
      },
    ],
    pastOpportunities: [
      {
        title: "Website Redesign",
        organization: "Community Food Bank",
        date: "April 2023",
        impact: "Increased online donations by 35%",
        skills: ["UX/UI Design", "Figma"],
      },
      {
        title: "User Research for Mobile App",
        organization: "Meals on Wheels",
        date: "March 2023",
        impact: "Identified key usability issues for elderly users",
        skills: ["User Research", "Prototyping"],
      },
      {
        title: "Marketing Materials Design",
        organization: "Food for All",
        date: "February 2023",
        impact: "Created materials for fundraising campaign that raised $50K",
        skills: ["Graphic Design", "Adobe Creative Suite"],
      },
    ],
    badges: [
      { name: "First Contribution", icon: Award, color: "bg-blue-100 text-blue-700" },
      { name: "Design Expert", icon: Star, color: "bg-purple-100 text-purple-700" },
      { name: "50+ Hours", icon: Clock, color: "bg-green-100 text-green-700" },
      { name: "Top Contributor", icon: Award, color: "bg-yellow-100 text-yellow-700" },
    ],
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
              B
            </div>
            <span className="font-bold text-xl">Bridge the Gap</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/opportunities" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Find Opportunities
            </Link>
            <Link href="/donate" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Donate Food
            </Link>
            <Link href="/volunteer" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Volunteer Skills
            </Link>
            <Link href="/about" className="text-sm font-medium hover:text-purple-600 transition-colors">
              About Us
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-200 to-pink-200 flex items-center justify-center">
              <span className="font-medium text-purple-800">JS</span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 bg-gray-50">
        {/* Profile Header */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
          <div className="container py-12">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
              <div className="w-32 h-32 rounded-full bg-white p-1 shadow-lg">
                <div className="w-full h-full rounded-full bg-gradient-to-br from-purple-200 to-pink-200 flex items-center justify-center">
                  <span className="font-bold text-purple-800 text-4xl">JS</span>
                </div>
              </div>

              <div className="flex-1 text-center md:text-left">
                <h1 className="text-3xl font-bold mb-2">{user.name}</h1>
                <p className="text-purple-100 mb-4">{user.title}</p>

                <div className="flex flex-wrap justify-center md:justify-start gap-4 mb-6">
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4 text-purple-200" />
                    <span className="text-sm">{user.location}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Mail className="h-4 w-4 text-purple-200" />
                    <span className="text-sm">{user.email}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Phone className="h-4 w-4 text-purple-200" />
                    <span className="text-sm">{user.phone}</span>
                  </div>
                </div>

                <div className="flex flex-wrap justify-center md:justify-start gap-2">
                  {user.badges.map((badge, i) => (
                    <div
                      key={i}
                      className={`${badge.color} px-3 py-1 rounded-full flex items-center gap-1 text-xs font-medium`}
                    >
                      <badge.icon className="h-3 w-3" />
                      {badge.name}
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" className="border-white text-white hover:bg-white/10">
                  <Settings className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
                <Button variant="outline" className="border-white text-white hover:bg-white/10">
                  <LogOut className="h-4 w-4 mr-2" />
                  Log Out
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="container py-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Sidebar */}
            <div className="space-y-6">
              {/* About */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-bold mb-4 flex items-center">
                  <User className="h-5 w-5 mr-2 text-purple-600" />
                  About
                </h2>
                <p className="text-gray-700 mb-6">{user.bio}</p>

                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Skills</h3>
                    <div className="flex flex-wrap gap-2">
                      {user.skills.map((skill, i) => (
                        <Badge key={i} variant="outline" className="bg-purple-50 text-purple-700 hover:bg-purple-100">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Availability</h3>
                    <p className="text-gray-700">{user.availability}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Preferred Location</h3>
                    <p className="text-gray-700">{user.preferredLocation}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Interests</h3>
                    <div className="flex flex-wrap gap-2">
                      {user.interests.map((interest, i) => (
                        <Badge key={i} variant="outline" className="bg-gray-50 text-gray-700 hover:bg-gray-100">
                          {interest}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Impact */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-bold mb-4 flex items-center">
                  <Award className="h-5 w-5 mr-2 text-purple-600" />
                  Your Impact
                </h2>

                <div className="space-y-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600 mb-1">{user.volunteeredHours}</div>
                    <div className="text-sm text-gray-500">Hours Volunteered</div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <div className="text-sm font-medium">Impact Points</div>
                      <div className="text-sm text-gray-500">{user.impactPoints}/500</div>
                    </div>
                    <Progress
                      value={user.impactPoints / 5}
                      className="h-2 bg-gray-100"
                      indicatorClassName="bg-gradient-to-r from-purple-600 to-pink-500"
                    />
                    <div className="text-xs text-gray-500 mt-2">50 more points until Gold Impact Badge</div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div className="bg-purple-50 rounded-lg p-3">
                      <div className="text-2xl font-bold text-purple-700 mb-1">{user.completedOpportunities}</div>
                      <div className="text-xs text-gray-600">Completed</div>
                    </div>
                    <div className="bg-pink-50 rounded-lg p-3">
                      <div className="text-2xl font-bold text-pink-700 mb-1">{user.savedOpportunities}</div>
                      <div className="text-xs text-gray-600">Saved</div>
                    </div>
                  </div>

                  <div className="pt-2">
                    <Button variant="outline" className="w-full">
                      View Impact Report
                    </Button>
                  </div>
                </div>
              </div>

              {/* Upcoming */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-lg font-bold mb-4 flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-purple-600" />
                  Upcoming
                </h2>

                {user.upcomingOpportunities.length > 0 ? (
                  <div className="space-y-4">
                    {user.upcomingOpportunities.map((opp, i) => (
                      <div
                        key={i}
                        className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg p-4 border border-purple-100"
                      >
                        <h3 className="font-medium text-purple-800 mb-1">{opp.title}</h3>
                        <p className="text-sm text-gray-600 mb-3">{opp.organization}</p>
                        <div className="flex items-center text-xs text-gray-500 mb-1">
                          <Calendar className="h-3 w-3 mr-1" />
                          {opp.date}
                        </div>
                        <div className="flex items-center text-xs text-gray-500 mb-1">
                          <Clock className="h-3 w-3 mr-1" />
                          {opp.time}
                        </div>
                        <div className="flex items-center text-xs text-gray-500">
                          <MapPin className="h-3 w-3 mr-1" />
                          {opp.location}
                        </div>
                        <div className="mt-4">
                          <Button
                            size="sm"
                            className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white"
                          >
                            View Details
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <Calendar className="h-6 w-6 text-gray-400" />
                    </div>
                    <p className="text-gray-500 mb-4">No upcoming opportunities</p>
                    <Button variant="outline" size="sm">
                      Find Opportunities
                    </Button>
                  </div>
                )}
              </div>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <Tabs defaultValue="contributions">
                  <TabsList className="w-full border-b rounded-none p-0">
                    <TabsTrigger
                      value="contributions"
                      className="rounded-none flex-1 py-3 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-700 data-[state=active]:shadow-none"
                    >
                      Contributions
                    </TabsTrigger>
                    <TabsTrigger
                      value="saved"
                      className="rounded-none flex-1 py-3 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-700 data-[state=active]:shadow-none"
                    >
                      Saved
                    </TabsTrigger>
                    <TabsTrigger
                      value="applications"
                      className="rounded-none flex-1 py-3 data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-700 data-[state=active]:shadow-none"
                    >
                      Applications
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="contributions" className="p-6">
                    <h2 className="text-xl font-bold mb-6">Your Contributions</h2>

                    <div className="space-y-6">
                      {user.pastOpportunities.map((opp, i) => (
                        <div key={i} className="border-b pb-6 last:border-0 last:pb-0">
                          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                            <div>
                              <h3 className="font-bold text-lg text-gray-900">{opp.title}</h3>
                              <p className="text-gray-600">{opp.organization}</p>
                            </div>
                            <div className="text-sm text-gray-500">{opp.date}</div>
                          </div>

                          <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg mb-4">
                            <div className="flex items-start">
                              <CheckCircle className="h-5 w-5 text-green-600 mr-2 flex-shrink-0 mt-0.5" />
                              <div>
                                <div className="font-medium text-green-800 mb-1">Impact</div>
                                <p className="text-sm text-gray-700">{opp.impact}</p>
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-2 mb-4">
                            {opp.skills.map((skill, j) => (
                              <Badge key={j} variant="outline" className="bg-purple-50 text-purple-700">
                                {skill}
                              </Badge>
                            ))}
                          </div>

                          <div className="flex gap-3">
                            <Button variant="outline" size="sm">
                              View Details
                            </Button>
                            <Button variant="ghost" size="sm" className="text-gray-500">
                              <Heart className="h-4 w-4 mr-1" />
                              Add to Portfolio
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="saved" className="p-6">
                    <h2 className="text-xl font-bold mb-6">Saved Opportunities</h2>

                    <div className="grid md:grid-cols-2 gap-6">
                      {[1, 2, 3, 4].map((i) => (
                        <div
                          key={i}
                          className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden group hover:shadow-md transition-shadow duration-300"
                        >
                          <div className="h-32 bg-gradient-to-br from-purple-400/10 to-pink-400/10 relative">
                            <div className="absolute inset-0 flex items-center justify-center">
                              <Image
                                src="/placeholder.svg?height=200&width=400"
                                alt="Organization"
                                width={400}
                                height={200}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          </div>
                          <div className="p-4">
                            <div className="flex items-start justify-between">
                              <div>
                                <h3 className="font-bold text-md mb-1 group-hover:text-purple-600 transition-colors">
                                  {
                                    [
                                      "UX Researcher",
                                      "Mobile App Developer",
                                      "Content Designer",
                                      "Accessibility Specialist",
                                    ][i - 1]
                                  }
                                </h3>
                                <p className="text-gray-600 text-sm">
                                  {
                                    ["Food for All", "Hunger Relief Network", "Community Pantry", "Meals on Wheels"][
                                      i - 1
                                    ]
                                  }
                                </p>
                              </div>
                              <Button variant="ghost" size="icon" className="rounded-full h-8 w-8 text-red-500">
                                <Heart className="h-4 w-4 fill-current" />
                                <span className="sr-only">Unsave</span>
                              </Button>
                            </div>
                            <div className="mt-3 flex items-center text-xs text-gray-500">
                              <MapPin className="w-3 h-3 mr-1" />
                              <span>{["Remote", "New York, NY", "Chicago, IL", "Remote"][i - 1]}</span>
                            </div>
                            <div className="mt-4">
                              <Button
                                size="sm"
                                className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white"
                              >
                                View Details
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="applications" className="p-6">
                    <h2 className="text-xl font-bold mb-6">Your Applications</h2>

                    <div className="space-y-4">
                      {[
                        {
                          title: "UX Audit for Food Donation App",
                          organization: "Food Rescue Network",
                          date: "Applied on May 2, 2023",
                          status: "In Review",
                          statusColor: "bg-yellow-100 text-yellow-800",
                        },
                        {
                          title: "Website Accessibility Consultant",
                          organization: "Community Food Bank",
                          date: "Applied on April 28, 2023",
                          status: "Interview Scheduled",
                          statusColor: "bg-blue-100 text-blue-800",
                        },
                        {
                          title: "Mobile App Prototype Designer",
                          organization: "Feeding Families",
                          date: "Applied on April 15, 2023",
                          status: "Accepted",
                          statusColor: "bg-green-100 text-green-800",
                        },
                      ].map((app, i) => (
                        <div
                          key={i}
                          className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-sm transition-shadow"
                        >
                          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                            <div>
                              <h3 className="font-medium text-purple-700">{app.title}</h3>
                              <p className="text-sm text-gray-600">{app.organization}</p>
                              <p className="text-xs text-gray-500 mt-1">{app.date}</p>
                            </div>
                            <div className="flex items-center gap-4">
                              <Badge className={`${app.statusColor}`}>{app.status}</Badge>
                              <Button variant="outline" size="sm">
                                View
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </div>

              {/* Recommendations */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-bold">Recommended for You</h2>
                  <Button variant="link" className="text-purple-600 p-0 h-auto">
                    View All
                  </Button>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  {[
                    {
                      title: "UX Researcher",
                      organization: "Food for All",
                      location: "Remote",
                      match: 95,
                    },
                    {
                      title: "Design System Specialist",
                      organization: "Hunger Relief Network",
                      location: "San Francisco, CA",
                      match: 88,
                    },
                  ].map((rec, i) => (
                    <div
                      key={i}
                      className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 border border-purple-100 relative"
                    >
                      <div className="absolute top-4 right-4 bg-white text-purple-700 text-xs font-bold px-2 py-1 rounded-full">
                        {rec.match}% Match
                      </div>
                      <h3 className="font-bold text-purple-800 mb-1">{rec.title}</h3>
                      <p className="text-sm text-gray-700 mb-3">{rec.organization}</p>
                      <div className="flex items-center text-xs text-gray-600 mb-4">
                        <MapPin className="h-3 w-3 mr-1" />
                        {rec.location}
                      </div>
                      <Button size="sm" className="w-full bg-white text-purple-700 hover:bg-gray-50">
                        View Opportunity
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-8">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
                B
              </div>
              <span className="font-bold text-white text-xl">Bridge the Gap</span>
            </div>
            <p className="text-sm text-gray-500">© {new Date().getFullYear()} Bridge the Gap. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
