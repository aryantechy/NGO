import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowRight,
  CheckCircle,
  Briefcase,
  Clock,
  Calendar,
  Users,
  Code,
  PenTool,
  TrendingUp,
  Truck,
  Search,
  Star,
  Heart,
} from "lucide-react"
import Image from "next/image"

export default function VolunteerSkillsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
              B
            </div>
            <span className="font-bold text-xl">Bridge the Gap</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/opportunities" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Find Opportunities
            </Link>
            <Link href="/donate" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Donate Food
            </Link>
            <Link href="/volunteer" className="text-sm font-medium text-purple-600 border-b-2 border-purple-600 pb-1">
              Volunteer Skills
            </Link>
            <Link href="/about" className="text-sm font-medium hover:text-purple-600 transition-colors">
              About Us
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="outline" size="sm">
                Log In
              </Button>
            </Link>
            <Link href="/signup">
              <Button
                className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white"
                size="sm"
              >
                Sign Up
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-pink-50 -z-10" />
          <div className="absolute -right-40 -top-40 w-96 h-96 bg-gradient-to-br from-purple-200/30 to-pink-200/30 rounded-full blur-3xl -z-10" />
          <div className="absolute -left-40 -bottom-40 w-96 h-96 bg-gradient-to-br from-purple-200/30 to-pink-200/30 rounded-full blur-3xl -z-10" />

          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <div className="inline-block px-3 py-1 rounded-full bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 text-sm font-medium mb-4">
                Share Your Expertise
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Volunteer Your{" "}
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-500">
                  Professional Skills
                </span>
              </h1>
              <p className="text-lg text-gray-600 mb-8">
                Use your professional expertise to help fight food insecurity. Your skills can make a meaningful
                difference in our community.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Button
                  className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white"
                  size="lg"
                >
                  Find Skill-Based Opportunities
                </Button>
                <Button variant="outline" size="lg">
                  How It Works
                </Button>
              </div>
            </div>

            <div className="grid md:grid-cols-4 gap-6 mt-16">
              {[
                {
                  title: "Technology",
                  description: "Web development, app design, database management",
                  icon: Code,
                  color: "from-blue-500 to-blue-700",
                },
                {
                  title: "Design & Marketing",
                  description: "Graphic design, social media, content creation",
                  icon: PenTool,
                  color: "from-purple-500 to-purple-700",
                },
                {
                  title: "Business & Strategy",
                  description: "Project management, analytics, fundraising",
                  icon: TrendingUp,
                  color: "from-pink-500 to-pink-700",
                },
                {
                  title: "Logistics & Operations",
                  description: "Supply chain, inventory, route optimization",
                  icon: Truck,
                  color: "from-green-500 to-green-700",
                },
              ].map((item, i) => (
                <div key={i} className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-100 to-pink-100 rounded-xl transform transition-transform group-hover:scale-[1.02] duration-300" />
                  <div className="relative p-6 bg-white rounded-xl border border-gray-100 shadow-sm h-full transition-transform group-hover:translate-y-[-4px] duration-300">
                    <div
                      className={`w-12 h-12 rounded-lg bg-gradient-to-br ${item.color} flex items-center justify-center text-white mb-4`}
                    >
                      <item.icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">{item.title}</h3>
                    <p className="text-gray-600 text-sm">{item.description}</p>
                    <div className="mt-4">
                      <Link
                        href="#"
                        className="inline-flex items-center text-sm font-medium text-purple-600 hover:text-purple-800"
                      >
                        View opportunities <ArrowRight className="ml-1 w-4 h-4" />
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-20 bg-white">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">How Skill-Based Volunteering Works</h2>
              <p className="text-gray-600">
                Bridge the Gap connects professionals with food assistance organizations that need your specific skills.
              </p>
            </div>

            <div className="max-w-5xl mx-auto">
              <div className="relative">
                {/* Timeline line */}
                <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gradient-to-b from-purple-500 to-pink-500 hidden md:block" />

                {[
                  {
                    title: "Create Your Profile",
                    description: "Sign up and tell us about your professional skills, experience, and availability.",
                    icon: Users,
                  },
                  {
                    title: "Browse Opportunities",
                    description: "Find projects that match your skills and interests from our partner organizations.",
                    icon: Search,
                  },
                  {
                    title: "Apply & Connect",
                    description: "Apply for opportunities and connect directly with the organization.",
                    icon: Briefcase,
                  },
                  {
                    title: "Make an Impact",
                    description: "Use your skills to help fight food insecurity in your community.",
                    icon: Heart,
                  },
                ].map((step, i) => (
                  <div key={i} className="relative mb-12 last:mb-0">
                    <div className={`md:flex items-center ${i % 2 === 0 ? "" : "md:flex-row-reverse"}`}>
                      <div className={`md:w-1/2 ${i % 2 === 0 ? "md:pr-12 md:text-right" : "md:pl-12"}`}>
                        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 relative">
                          <div
                            className="absolute top-6 hidden md:block h-0.5 w-8 bg-gradient-to-r from-purple-500 to-pink-500 
                            ${i % 2 === 0 ? 'right-0 translate-x-full' : 'left-0 -translate-x-full'}"
                          />
                          <h3 className="text-xl font-bold mb-3 flex items-center md:block">
                            <div className="md:hidden w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white mr-3 flex-shrink-0">
                              <step.icon className="w-5 h-5" />
                            </div>
                            <span>
                              Step {i + 1}: {step.title}
                            </span>
                          </h3>
                          <p className="text-gray-600">{step.description}</p>
                        </div>
                      </div>

                      <div className="hidden md:flex w-1/2 items-center justify-center">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white z-10">
                          <step.icon className="w-6 h-6" />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="text-center mt-12">
                <Button className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                  Get Started Now
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Opportunities */}
        <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">Featured Skill-Based Opportunities</h2>
              <p className="text-gray-600">
                These organizations need your professional expertise right now. Browse our featured opportunities.
              </p>
            </div>

            <Tabs defaultValue="all" className="max-w-5xl mx-auto">
              <TabsList className="grid w-full grid-cols-4 mb-8">
                <TabsTrigger
                  value="all"
                  className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                >
                  All Skills
                </TabsTrigger>
                <TabsTrigger
                  value="tech"
                  className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                >
                  Technology
                </TabsTrigger>
                <TabsTrigger
                  value="design"
                  className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                >
                  Design
                </TabsTrigger>
                <TabsTrigger
                  value="business"
                  className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700"
                >
                  Business
                </TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="space-y-6">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[
                    {
                      title: "Food Inventory Manager",
                      organization: "Community Food Bank",
                      location: "San Francisco, CA",
                      type: "Remote",
                      skills: ["Database Management", "Inventory Systems"],
                      urgent: true,
                    },
                    {
                      title: "Website Redesign",
                      organization: "Meals on Wheels",
                      location: "Chicago, IL",
                      type: "Remote",
                      skills: ["UI/UX Design", "Web Development"],
                      urgent: false,
                    },
                    {
                      title: "Delivery Route Optimizer",
                      organization: "Food Rescue Network",
                      location: "Austin, TX",
                      type: "Hybrid",
                      skills: ["Logistics", "Route Planning"],
                      urgent: true,
                    },
                    {
                      title: "Social Media Strategist",
                      organization: "Feeding Families",
                      location: "New York, NY",
                      type: "Remote",
                      skills: ["Social Media", "Content Creation"],
                      urgent: false,
                    },
                    {
                      title: "Grant Writer",
                      organization: "Hunger Relief Coalition",
                      location: "Boston, MA",
                      type: "Remote",
                      skills: ["Grant Writing", "Research"],
                      urgent: false,
                    },
                    {
                      title: "Mobile App Developer",
                      organization: "Food for All",
                      location: "Seattle, WA",
                      type: "Remote",
                      skills: ["React Native", "API Integration"],
                      urgent: true,
                    },
                  ].map((item, i) => (
                    <div
                      key={i}
                      className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden group hover:shadow-md transition-shadow duration-300"
                    >
                      <div className="h-40 bg-gradient-to-br from-purple-400/10 to-pink-400/10 relative">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Image
                            src="/placeholder.svg?height=200&width=400"
                            alt={item.organization}
                            width={400}
                            height={200}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        {item.urgent && (
                          <div className="absolute top-4 right-4 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center">
                            <Clock className="w-3 h-3 mr-1" /> Urgent Need
                          </div>
                        )}
                      </div>
                      <div className="p-6">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-bold text-lg mb-1 group-hover:text-purple-600 transition-colors">
                              {item.title}
                            </h3>
                            <p className="text-gray-600 text-sm">{item.organization}</p>
                          </div>
                          <Button variant="ghost" size="icon" className="rounded-full h-8 w-8">
                            <Heart className="h-4 w-4" />
                            <span className="sr-only">Save</span>
                          </Button>
                        </div>
                        <div className="mt-4 flex items-center text-sm text-gray-500">
                          <div className="flex items-center mr-4">
                            <Calendar className="w-4 h-4 mr-1" />
                            <span>5-10 hrs/week</span>
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            <span>3 months</span>
                          </div>
                        </div>
                        <div className="mt-2 flex items-center text-sm text-gray-500">
                          <div className="flex items-center">
                            <Briefcase className="w-4 h-4 mr-1" />
                            <span>{item.type}</span>
                          </div>
                        </div>
                        <div className="mt-4 flex flex-wrap gap-2">
                          {item.skills.map((skill, j) => (
                            <span
                              key={j}
                              className="inline-block bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded-full"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                        <div className="mt-6">
                          <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="text-center mt-8">
                  <Button variant="outline">View All Opportunities</Button>
                </div>
              </TabsContent>

              <TabsContent value="tech" className="space-y-6">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[
                    {
                      title: "Food Inventory Manager",
                      organization: "Community Food Bank",
                      location: "San Francisco, CA",
                      type: "Remote",
                      skills: ["Database Management", "Inventory Systems"],
                      urgent: true,
                    },
                    {
                      title: "Mobile App Developer",
                      organization: "Food for All",
                      location: "Seattle, WA",
                      type: "Remote",
                      skills: ["React Native", "API Integration"],
                      urgent: true,
                    },
                    {
                      title: "Data Analyst",
                      organization: "Hunger Relief Coalition",
                      location: "Boston, MA",
                      type: "Remote",
                      skills: ["Data Analysis", "Visualization"],
                      urgent: false,
                    },
                  ].map((item, i) => (
                    <div
                      key={i}
                      className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden group hover:shadow-md transition-shadow duration-300"
                    >
                      <div className="h-40 bg-gradient-to-br from-purple-400/10 to-pink-400/10 relative">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Image
                            src="/placeholder.svg?height=200&width=400"
                            alt={item.organization}
                            width={400}
                            height={200}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        {item.urgent && (
                          <div className="absolute top-4 right-4 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center">
                            <Clock className="w-3 h-3 mr-1" /> Urgent Need
                          </div>
                        )}
                      </div>
                      <div className="p-6">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-bold text-lg mb-1 group-hover:text-purple-600 transition-colors">
                              {item.title}
                            </h3>
                            <p className="text-gray-600 text-sm">{item.organization}</p>
                          </div>
                          <Button variant="ghost" size="icon" className="rounded-full h-8 w-8">
                            <Heart className="h-4 w-4" />
                            <span className="sr-only">Save</span>
                          </Button>
                        </div>
                        <div className="mt-4 flex items-center text-sm text-gray-500">
                          <div className="flex items-center mr-4">
                            <Calendar className="w-4 h-4 mr-1" />
                            <span>5-10 hrs/week</span>
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            <span>3 months</span>
                          </div>
                        </div>
                        <div className="mt-2 flex items-center text-sm text-gray-500">
                          <div className="flex items-center">
                            <Briefcase className="w-4 h-4 mr-1" />
                            <span>{item.type}</span>
                          </div>
                        </div>
                        <div className="mt-4 flex flex-wrap gap-2">
                          {item.skills.map((skill, j) => (
                            <span
                              key={j}
                              className="inline-block bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded-full"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                        <div className="mt-6">
                          <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="text-center mt-8">
                  <Button variant="outline">View All Tech Opportunities</Button>
                </div>
              </TabsContent>

              <TabsContent value="design" className="space-y-6">
                {/* Similar content structure for design opportunities */}
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <PenTool className="h-8 w-8 text-purple-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">Design opportunities coming soon</h3>
                  <p className="text-gray-500 mb-6">We're currently adding new design opportunities</p>
                  <Button variant="outline">Get notified when available</Button>
                </div>
              </TabsContent>

              <TabsContent value="business" className="space-y-6">
                {/* Similar content structure for business opportunities */}
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[
                    {
                      title: "Grant Writer",
                      organization: "Hunger Relief Coalition",
                      location: "Boston, MA",
                      type: "Remote",
                      skills: ["Grant Writing", "Research"],
                      urgent: false,
                    },
                    {
                      title: "Fundraising Strategist",
                      organization: "Food for All",
                      location: "Seattle, WA",
                      type: "Remote",
                      skills: ["Fundraising", "Strategy"],
                      urgent: false,
                    },
                  ].map((item, i) => (
                    <div
                      key={i}
                      className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden group hover:shadow-md transition-shadow duration-300"
                    >
                      <div className="h-40 bg-gradient-to-br from-purple-400/10 to-pink-400/10 relative">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Image
                            src="/placeholder.svg?height=200&width=400"
                            alt={item.organization}
                            width={400}
                            height={200}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        {item.urgent && (
                          <div className="absolute top-4 right-4 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center">
                            <Clock className="w-3 h-3 mr-1" /> Urgent Need
                          </div>
                        )}
                      </div>
                      <div className="p-6">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-bold text-lg mb-1 group-hover:text-purple-600 transition-colors">
                              {item.title}
                            </h3>
                            <p className="text-gray-600 text-sm">{item.organization}</p>
                          </div>
                          <Button variant="ghost" size="icon" className="rounded-full h-8 w-8">
                            <Heart className="h-4 w-4" />
                            <span className="sr-only">Save</span>
                          </Button>
                        </div>
                        <div className="mt-4 flex items-center text-sm text-gray-500">
                          <div className="flex items-center mr-4">
                            <Calendar className="w-4 h-4 mr-1" />
                            <span>5-10 hrs/week</span>
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            <span>3 months</span>
                          </div>
                        </div>
                        <div className="mt-2 flex items-center text-sm text-gray-500">
                          <div className="flex items-center">
                            <Briefcase className="w-4 h-4 mr-1" />
                            <span>{item.type}</span>
                          </div>
                        </div>
                        <div className="mt-4 flex flex-wrap gap-2">
                          {item.skills.map((skill, j) => (
                            <span
                              key={j}
                              className="inline-block bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded-full"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                        <div className="mt-6">
                          <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="text-center mt-8">
                  <Button variant="outline">View All Business Opportunities</Button>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Volunteer Form */}
        <section className="py-20 bg-white">
          <div className="container">
            <div className="max-w-5xl mx-auto">
              <div className="grid md:grid-cols-2 gap-12 items-center">
                <div>
                  <h2 className="text-3xl font-bold mb-6">Register as a Skilled Volunteer</h2>
                  <p className="text-gray-600 mb-8">
                    Share your professional skills to help fight food insecurity. Fill out this form to join our network
                    of skilled volunteers.
                  </p>

                  <div className="space-y-6">
                    <div className="flex items-start">
                      <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center mr-4 flex-shrink-0">
                        <CheckCircle className="h-5 w-5 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-medium mb-1">Flexible Commitment</h3>
                        <p className="text-sm text-gray-600">
                          Choose opportunities that fit your schedule, from one-time projects to ongoing roles.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center mr-4 flex-shrink-0">
                        <CheckCircle className="h-5 w-5 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-medium mb-1">Remote Options Available</h3>
                        <p className="text-sm text-gray-600">
                          Many of our opportunities can be completed remotely, allowing you to volunteer from anywhere.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center mr-4 flex-shrink-0">
                        <CheckCircle className="h-5 w-5 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-medium mb-1">Professional Development</h3>
                        <p className="text-sm text-gray-600">
                          Gain valuable experience while making a difference in your community.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center mr-4 flex-shrink-0">
                        <CheckCircle className="h-5 w-5 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-medium mb-1">Meaningful Impact</h3>
                        <p className="text-sm text-gray-600">
                          See the direct impact of your contributions on food security in your community.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border border-purple-100">
                    <div className="flex items-center">
                      <div className="w-12 h-12 rounded-full flex items-center justify-center bg-white mr-4">
                        <Star className="h-6 w-6 text-yellow-400" />
                      </div>
                      <div>
                        <h3 className="font-medium">Join 10,000+ skilled volunteers</h3>
                        <p className="text-sm text-gray-600">
                          Our volunteers have contributed over 50,000 hours of professional expertise
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
                  <h3 className="text-xl font-bold mb-6">Volunteer Registration</h3>
                  <form className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label htmlFor="first-name" className="text-sm font-medium">
                          First name
                        </label>
                        <Input id="first-name" placeholder="Enter your first name" />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="last-name" className="text-sm font-medium">
                          Last name
                        </label>
                        <Input id="last-name" placeholder="Enter your last name" />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email
                      </label>
                      <Input id="email" type="email" placeholder="Enter your email" />
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-sm font-medium">
                        Phone number
                      </label>
                      <Input id="phone" placeholder="Enter your phone number" />
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="skills" className="text-sm font-medium">
                        Professional skills
                      </label>
                      <Textarea
                        id="skills"
                        placeholder="List your professional skills (e.g., web development, graphic design, project management)"
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="availability" className="text-sm font-medium">
                        Availability
                      </label>
                      <select
                        id="availability"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <option value="">Select your availability</option>
                        <option value="1-5">1-5 hours per week</option>
                        <option value="5-10">5-10 hours per week</option>
                        <option value="10+">10+ hours per week</option>
                        <option value="one-time">One-time projects only</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="location-preference" className="text-sm font-medium">
                        Location preference
                      </label>
                      <select
                        id="location-preference"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <option value="">Select your preference</option>
                        <option value="remote">Remote only</option>
                        <option value="in-person">In-person only</option>
                        <option value="hybrid">Hybrid (both remote and in-person)</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="hear-about" className="text-sm font-medium">
                        How did you hear about us?
                      </label>
                      <Input id="hear-about" placeholder="How did you hear about Bridge the Gap?" />
                    </div>

                    <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white">
                      Register as Volunteer
                    </Button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">Volunteer Success Stories</h2>
              <p className="text-gray-600">Hear from professionals who have made a difference with their skills.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {[
                {
                  name: "Michael Chen",
                  title: "Web Developer",
                  image: "/placeholder.svg?height=100&width=100",
                  quote:
                    "Using my coding skills to build a food inventory system for the local food bank was incredibly rewarding. I could see the direct impact of my work as they were able to serve 30% more families with the same resources.",
                },
                {
                  name: "Sarah Johnson",
                  title: "Marketing Specialist",
                  image: "/placeholder.svg?height=100&width=100",
                  quote:
                    "I helped create a social media campaign that increased donations by 45%. It's amazing to see how my professional skills could make such a difference in fighting food insecurity in our community.",
                },
                {
                  name: "David Rodriguez",
                  title: "Logistics Manager",
                  image: "/placeholder.svg?height=100&width=100",
                  quote:
                    "Optimizing delivery routes for Meals on Wheels saved them thousands in fuel costs and allowed them to reach more seniors. It's the same work I do professionally, but with a much more meaningful impact.",
                },
              ].map((testimonial, i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm p-8 border border-gray-100 relative">
                  <div className="absolute top-0 right-0 transform translate-x-4 -translate-y-4">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M10 11h-4a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1h3a1 1 0 0 1 1 1v6c0 2.667 -1.333 4.333 -4 5"></path>
                        <path d="M19 11h-4a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1h3a1 1 0 0 1 1 1v6c0 2.667 -1.333 4.333 -4 5"></path>
                      </svg>
                    </div>
                  </div>

                  <div className="mb-6">
                    <p className="text-gray-700 italic">"{testimonial.quote}"</p>
                  </div>

                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                      <Image
                        src={testimonial.image || "/placeholder.svg"}
                        alt={testimonial.name}
                        width={48}
                        height={48}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-bold">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.title}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center mt-12">
              <Button variant="outline">Read More Stories</Button>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-purple-600 to-pink-600 text-white">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to make an impact with your skills?</h2>
              <p className="text-xl opacity-90 mb-8">
                Join our community of skilled volunteers and help bridge the gap between food surplus and those in need.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Button size="lg" className="bg-white text-purple-700 hover:bg-gray-100">
                  Sign Up Now
                </Button>
                <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
                  Browse Opportunities
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="bg-gradient-to-r from-purple-600 to-pink-500 w-8 h-8 rounded-md flex items-center justify-center text-white font-bold">
                  B
                </div>
                <span className="font-bold text-white text-xl">Bridge the Gap</span>
              </div>
              <p className="text-sm text-gray-400 mb-4">
                Connecting skilled volunteers with food distribution networks to create efficient, sustainable community
                support systems.
              </p>
              <div className="flex gap-4">
                {["twitter", "facebook", "instagram", "linkedin"].map((social) => (
                  <a key={social} href="#" className="text-gray-400 hover:text-white transition-colors">
                    <span className="sr-only">{social}</span>
                    <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center">
                      <span className="text-xs">{social[0].toUpperCase()}</span>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            {[
              {
                title: "Platform",
                links: ["How it works", "Features", "Testimonials", "Pricing", "FAQ"],
              },
              {
                title: "Resources",
                links: ["Blog", "Partners", "Community", "Help Center", "Contact Us"],
              },
              {
                title: "Legal",
                links: ["Terms of Service", "Privacy Policy", "Cookie Policy", "Data Processing", "Accessibility"],
              },
            ].map((column, i) => (
              <div key={i}>
                <h3 className="font-bold text-white mb-4">{column.title}</h3>
                <ul className="space-y-2">
                  {column.links.map((link, j) => (
                    <li key={j}>
                      <a href="#" className="text-sm text-gray-400 hover:text-white transition-colors">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-500">© {new Date().getFullYear()} Bridge the Gap. All rights reserved.</p>
            <div className="mt-4 md:mt-0">
              <select className="bg-gray-800 text-gray-300 text-sm rounded-md px-3 py-1.5 border border-gray-700">
                <option>English (US)</option>
                <option>Español</option>
                <option>Français</option>
              </select>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
